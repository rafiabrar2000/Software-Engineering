<h1>Assign Course</h1>



<form method=get action=assign_teacher_result.php>

	Teacher ID: <input type=text name=teacher_id> <br>

	<p>

	Course ID: <input type=text name=course_id> <br>

	<p>

	<input type=submit value=Insert>

</form>