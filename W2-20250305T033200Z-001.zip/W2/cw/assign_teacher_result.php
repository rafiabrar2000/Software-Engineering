<?php


	$teacher_id = $_GET["teacher_id"];

	$course_id = $_GET["course_id"];



	require_once('db_connect.php');

	$connect = mysqli_connect( HOST, USER, PASS, DB )

		or die("Can not connect");



	$query 	= "UPDATE teacher SET course_id='$course_id' WHERE teacher_id = $teacher_id";

	echo $query;



	mysqli_query( $connect, $query )

		or die("Can not execute query");



	// echo "<p>Record updated:<br> f0 = $f0 <br> f1 = $f1";



	echo "<p><a href=read_teacher.php>READ all records</a>";

?>