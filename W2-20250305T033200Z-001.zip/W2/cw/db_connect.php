<?php

	// Defining Constants
	define( 'HOST', 'localhost' );
	define( 'DB', 'Spring2020_Assignment' );
	define( 'USER', 'root' );
	define( 'PASS', '' );
?>