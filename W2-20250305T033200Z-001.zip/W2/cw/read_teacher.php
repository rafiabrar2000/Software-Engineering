<?php
	require_once('db_connect.php');
	$connect = mysqli_connect( HOST, USER, PASS, DB )
		or die("Can not connect");


	$results = mysqli_query( $connect, "SELECT * FROM teacher" )
		or die("Can not execute query");

	// print_r($results);

	echo "<table border> \n";
	echo "<th>Name</th> <th>Course Id</th> <th>Delete</th> <th>Update</th> \n";

	while( $rows = mysqli_fetch_array( $results ) ) {
		// print_r( $rows );
		extract( $rows );

		echo "<tr>";
		echo "<td> $name </td>";
		echo "<td> $course_id </td>";
		echo "<td> <a href = 'delete.php?id=$teacher_id'> Delete </a> </td>";
		echo "<td> <a href = 'update_input.php?id=$teacher_id&name=$name&course=$course_id'> Update </a> </td>";
		echo "</tr> \n";
	}

	echo "</table> \n";

	echo "<p><a href=assign_teacher.php>Assign a Course to Teacher</a>";
?>